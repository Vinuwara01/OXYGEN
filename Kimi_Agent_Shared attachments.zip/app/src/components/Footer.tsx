import { NAV_LINKS, SOCIAL } from '@/config'

const SOCIALS = [
  { label: 'Instagram', href: SOCIAL.instagram },
  { label: 'Facebook', href: SOCIAL.facebook },
  { label: 'WhatsApp', href: SOCIAL.whatsapp },
]

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#0a0a0a] text-white">
      <div className="mx-auto max-w-[1400px] px-5 py-16 md:px-10 md:py-20">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-12">
          {/* Brand */}
          <div className="md:col-span-5">
            <a href="#home" className="flex items-baseline gap-2">
              <span className="font-display text-2xl font-black uppercase tracking-tight">Oxygen</span>
              <span className="font-display text-2xl font-black uppercase tracking-tight text-[#e10600]">
                Gym
              </span>
            </a>
            <p className="mt-4 font-display text-xs font-bold uppercase tracking-[0.3em] text-white/45">
              Train with purpose.
            </p>
          </div>

          {/* Pages */}
          <nav className="md:col-span-4" aria-label="Footer">
            <ul className="grid grid-cols-2 gap-x-8 gap-y-3">
              {NAV_LINKS.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="font-display text-xs font-bold uppercase tracking-[0.22em] text-white/65 transition-colors hover:text-white"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Social */}
          <div className="md:col-span-3">
            <ul className="flex flex-col gap-3">
              {SOCIALS.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-2 font-display text-xs font-bold uppercase tracking-[0.22em] text-white/65 transition-colors hover:text-white"
                  >
                    {s.label}
                    <span className="text-[#e10600] transition-transform duration-300 group-hover:translate-x-1">
                      ↗
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-3 border-t border-white/10 pt-8 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-white/40">© 2026 OXYGEN GYM. All rights reserved.</p>
          <p className="font-display text-[10px] font-bold uppercase tracking-[0.3em] text-white/30">
            Sri Lanka
          </p>
        </div>
      </div>
    </footer>
  )
}
