import { useEffect, useState } from 'react'
import { NAV_LINKS } from '@/config'

export default function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  const solid = scrolled || open

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          solid
            ? 'border-b border-white/10 bg-[#0a0a0a]/90 backdrop-blur-md'
            : 'border-b border-transparent bg-transparent'
        }`}
      >
        <div
          className={`mx-auto flex max-w-[1400px] items-center justify-between px-5 transition-all duration-500 md:px-10 ${
            scrolled ? 'py-3.5' : 'py-5 md:py-7'
          }`}
        >
          {/* Wordmark */}
          <a href="#home" className="group flex items-baseline gap-2" onClick={() => setOpen(false)}>
            <span className="font-display text-lg font-black uppercase tracking-tight text-white md:text-xl">
              Oxygen
            </span>
            <span className="font-display text-lg font-black uppercase tracking-tight text-[#e10600] md:text-xl">
              Gym
            </span>
          </a>

          {/* Desktop links */}
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
            {NAV_LINKS.map((l) => (
              <a
                key={l.label}
                href={l.href}
                className="nav-link font-display text-[11px] font-bold uppercase tracking-[0.22em] text-white/80 transition-colors hover:text-white"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="#memberships"
              className="btn-wipe btn-wipe-red hidden bg-[#e10600] px-6 py-3 font-display text-[11px] font-bold uppercase tracking-[0.22em] text-white lg:inline-block"
            >
              Join Now
            </a>

            {/* Hamburger */}
            <button
              type="button"
              aria-label={open ? 'Close menu' : 'Open menu'}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
              className="flex h-11 w-11 flex-col items-center justify-center gap-[6px] lg:hidden"
            >
              <span
                className={`h-[2px] w-6 bg-white transition-transform duration-300 ${
                  open ? 'translate-y-[8px] rotate-45' : ''
                }`}
              />
              <span
                className={`h-[2px] w-6 bg-white transition-opacity duration-300 ${open ? 'opacity-0' : ''}`}
              />
              <span
                className={`h-[2px] w-6 bg-white transition-transform duration-300 ${
                  open ? '-translate-y-[8px] -rotate-45' : ''
                }`}
              />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile full-screen menu */}
      <div
        className={`fixed inset-0 z-40 flex flex-col justify-between bg-[#0a0a0a] px-6 pb-10 pt-28 transition-all duration-500 lg:hidden ${
          open ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0'
        }`}
        aria-hidden={!open}
      >
        <nav className="flex flex-col gap-2" aria-label="Mobile">
          {NAV_LINKS.map((l, i) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setOpen(false)}
              className={`border-b border-white/10 py-4 font-display text-4xl font-black uppercase tracking-tight text-white transition-all duration-500 ${
                open ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
              }`}
              style={{ transitionDelay: open ? `${120 + i * 60}ms` : '0ms' }}
            >
              {l.label}
            </a>
          ))}
        </nav>
        <a
          href="#memberships"
          onClick={() => setOpen(false)}
          className="block w-full bg-[#e10600] py-4 text-center font-display text-sm font-bold uppercase tracking-[0.25em] text-white"
        >
          Join Now
        </a>
      </div>
    </>
  )
}
