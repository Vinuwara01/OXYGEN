import { useEffect } from 'react'

/**
 * Observes every `.reveal` / `.reveal-img` element once on mount and adds
 * `.is-visible` when it enters the viewport. Supports optional stagger via
 * the `data-delay` attribute (milliseconds).
 */
export function useReveal() {
  useEffect(() => {
    const els = Array.from(
      document.querySelectorAll<HTMLElement>('.reveal, .reveal-img'),
    )

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue
          const el = entry.target as HTMLElement
          const delay = Number(el.dataset.delay ?? 0)
          window.setTimeout(() => el.classList.add('is-visible'), delay)
          io.unobserve(el)
        }
      },
      { threshold: 0.15, rootMargin: '0px 0px -8% 0px' },
    )

    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])
}
