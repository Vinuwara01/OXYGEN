/**
 * OXYGEN GYM — editable site content.
 * Replace the placeholder values below with the gym's real details.
 * Prices are intentionally not listed — members are asked to contact the gym.
 */

export const SITE = {
  name: 'OXYGEN GYM',
  tagline: 'TRAIN WITH PURPOSE.',
}

export const CONTACT = {
  address: '[GYM ADDRESS]',
  phoneDisplay: '[PHONE NUMBER]',
  phoneHref: 'tel:+94000000000', // replace with real number
  whatsappDisplay: '[WHATSAPP NUMBER]',
  // Replace 94000000000 with the real WhatsApp number (country code + number, no symbols)
  whatsappHref: 'https://wa.me/94000000000',
  email: '[EMAIL ADDRESS]',
  hours: '[OPENING HOURS]',
  // Replace with the real Google Maps link when available
  directionsHref: 'https://maps.google.com/?q=Sri+Lanka',
}

export const SOCIAL = {
  instagram: 'https://instagram.com/', // replace with real profile
  facebook: 'https://facebook.com/', // replace with real page
  whatsapp: 'https://wa.me/94000000000',
}

export const NAV_LINKS = [
  { label: 'HOME', href: '#home' },
  { label: 'MEMBERSHIPS', href: '#memberships' },
  { label: 'TRAINING', href: '#training' },
  { label: 'ABOUT', href: '#about' },
  { label: 'CONTACT', href: '#contact' },
]
