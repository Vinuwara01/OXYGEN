import strength from '@/assets/strength.jpg'
import conditioning from '@/assets/conditioning.jpg'
import personal from '@/assets/personal.jpg'

const CATEGORIES = [
  {
    title: 'Strength',
    text: 'Build power, muscle and confidence with serious resistance training.',
    img: strength,
    alt: 'Athlete performing a heavy deadlift in a dark gym',
  },
  {
    title: 'Conditioning',
    text: 'Improve endurance, athletic performance and overall fitness.',
    img: conditioning,
    alt: 'Athlete training with battle ropes on the gym floor',
  },
  {
    title: 'Personal Training',
    text: 'Structured guidance designed around your goals.',
    img: personal,
    alt: 'Coach guiding a member through a supervised session',
  },
]

export default function Training() {
  return (
    <section id="training" className="bg-[#f4f4f4] text-[#0a0a0a]">
      <div className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-36">
        <p className="eyebrow reveal mb-5">Training</p>
        <div className="mb-14 flex flex-col gap-6 md:mb-20 md:flex-row md:items-end md:justify-between">
          <h2
            className="reveal font-display text-[12vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5.4vw]"
            data-delay="80"
          >
            Train your<br />way.
          </h2>
          <p className="reveal max-w-sm text-base leading-relaxed text-[#0a0a0a]/60" data-delay="160">
            Three disciplines. One standard. Choose the path that fits your
            goals — or combine all three.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 md:gap-5">
          {CATEGORIES.map((c, i) => (
            <a
              key={c.title}
              href="#memberships"
              className="group block"
              aria-label={`${c.title} — view memberships`}
            >
              <div
                className="reveal-img relative aspect-[3/4] overflow-hidden bg-[#0a0a0a]"
                data-delay={i * 100}
              >
                <img
                  src={c.img}
                  alt={c.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                <span className="absolute left-5 top-5 font-display text-[11px] font-bold uppercase tracking-[0.3em] text-white/70">
                  0{i + 1}
                </span>
                <div className="absolute inset-x-5 bottom-5">
                  <h3 className="font-display text-2xl font-black uppercase tracking-tight text-white md:text-3xl">
                    {c.title}
                  </h3>
                  <p className="mt-2 max-w-[30ch] text-sm leading-relaxed text-white/70">
                    {c.text}
                  </p>
                  <span className="mt-4 inline-block h-[2px] w-10 bg-[#e10600] transition-all duration-500 group-hover:w-full" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
