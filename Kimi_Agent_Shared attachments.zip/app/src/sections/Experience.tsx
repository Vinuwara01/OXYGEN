import experience from '@/assets/experience.jpg'

const POINTS = [
  'Quality equipment, maintained properly',
  'A clean, focused training environment',
  'A serious atmosphere — no distractions',
  'A community that pushes each other forward',
]

export default function Experience() {
  return (
    <section className="relative overflow-hidden bg-[#0a0a0a] text-white">
      {/* Full-bleed image */}
      <div className="reveal-img relative h-[60vh] overflow-hidden md:h-[75vh]">
        <img
          src={experience}
          alt="Wide view of the Oxygen Gym floor with racks and machines"
          loading="lazy"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
      </div>

      {/* Copy overlaps the image */}
      <div className="relative mx-auto -mt-32 max-w-[1400px] px-5 pb-24 md:-mt-48 md:px-10 md:pb-36">
        <div className="max-w-2xl">
          <p className="eyebrow reveal mb-5">The gym</p>
          <h2
            className="reveal font-display text-[12vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5.4vw]"
            data-delay="80"
          >
            Built for<br />performance.
          </h2>
        </div>

        <ul className="mt-12 grid max-w-3xl grid-cols-1 gap-x-10 sm:grid-cols-2">
          {POINTS.map((p, i) => (
            <li
              key={p}
              className="reveal flex items-center gap-4 border-t border-white/15 py-5"
              data-delay={i * 90}
            >
              <span className="font-display text-xs font-bold text-[#e10600]">0{i + 1}</span>
              <span className="text-base text-white/75 md:text-lg">{p}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
