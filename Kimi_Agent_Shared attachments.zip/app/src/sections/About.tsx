import about from '@/assets/about.jpg'

export default function About() {
  return (
    <section id="about" className="bg-[#f4f4f4] text-[#0a0a0a]">
      <div className="mx-auto grid max-w-[1400px] grid-cols-1 items-center gap-12 px-5 py-24 md:px-10 md:py-36 lg:grid-cols-2 lg:gap-16">
        {/* Image first on desktop */}
        <div className="reveal-img order-2 aspect-[4/5] overflow-hidden lg:order-1 lg:aspect-[5/6]">
          <img
            src={about}
            alt="Member training with a barbell squat at Oxygen Gym"
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>

        <div className="order-1 lg:order-2">
          <p className="eyebrow reveal mb-6">About</p>
          <h2
            className="reveal font-display text-[12vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5vw]"
            data-delay="80"
          >
            Why Oxygen?
          </h2>
          <div
            className="reveal mt-8 flex max-w-lg flex-col gap-5 text-lg leading-relaxed text-[#0a0a0a]/65"
            data-delay="160"
          >
            <p>
              Oxygen Gym exists for one reason: to give people in Sri Lanka a
              place where training is taken seriously.
            </p>
            <p>
              We keep it simple — a focused environment, quality equipment and
              coaching that pays attention. Whether you are building strength,
              improving fitness or chasing performance, this is a place to do
              the work properly.
            </p>
          </div>
          <div className="reveal mt-10 flex items-center gap-4" data-delay="240">
            <span className="h-[2px] w-14 bg-[#e10600]" aria-hidden="true" />
            <span className="font-display text-xs font-bold uppercase tracking-[0.3em] text-[#0a0a0a]/50">
              Train with purpose
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
