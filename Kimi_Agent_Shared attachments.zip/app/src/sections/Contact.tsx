import { CONTACT } from '@/config'

const ROWS = [
  { label: 'Location', value: CONTACT.address },
  { label: 'Phone', value: CONTACT.phoneDisplay },
  { label: 'WhatsApp', value: CONTACT.whatsappDisplay },
  { label: 'Email', value: CONTACT.email },
  { label: 'Opening Hours', value: CONTACT.hours },
]

export default function Contact() {
  return (
    <section id="contact" className="bg-[#0a0a0a] text-white">
      <div className="mx-auto grid max-w-[1400px] grid-cols-1 gap-14 px-5 py-24 md:px-10 md:py-36 lg:grid-cols-2 lg:gap-20">
        {/* Details */}
        <div>
          <p className="eyebrow reveal mb-6">Contact</p>
          <h2
            className="reveal font-display text-[12vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5vw]"
            data-delay="80"
          >
            Find the gym.
          </h2>

          <dl className="mt-12">
            {ROWS.map((r, i) => (
              <div
                key={r.label}
                className="reveal flex flex-col gap-1 border-t border-white/10 py-5 sm:flex-row sm:items-baseline sm:justify-between sm:gap-8"
                data-delay={i * 70}
              >
                <dt className="font-display text-[11px] font-bold uppercase tracking-[0.3em] text-white/45">
                  {r.label}
                </dt>
                <dd className="text-base text-white/85 sm:text-right md:text-lg">{r.value}</dd>
              </div>
            ))}
          </dl>

          <div className="reveal mt-10 flex flex-col gap-3 sm:flex-row" data-delay="200">
            <a
              href={CONTACT.phoneHref}
              className="btn-wipe btn-wipe-ghost border border-white/40 px-8 py-4 text-center font-display text-xs font-bold uppercase tracking-[0.25em] text-white"
            >
              Call Now
            </a>
            <a
              href={CONTACT.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-wipe btn-wipe-red bg-[#e10600] px-8 py-4 text-center font-display text-xs font-bold uppercase tracking-[0.25em] text-white"
            >
              WhatsApp
            </a>
            <a
              href={CONTACT.directionsHref}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-wipe btn-wipe-ghost border border-white/40 px-8 py-4 text-center font-display text-xs font-bold uppercase tracking-[0.25em] text-white"
            >
              Get Directions
            </a>
          </div>
        </div>

        {/* Map placeholder — replace with Google Maps embed */}
        <div className="reveal-img relative min-h-[320px] overflow-hidden border border-white/10 lg:min-h-0">
          <div className="absolute inset-0 bg-[#111]" />
          {/* subtle grid texture */}
          <div
            className="absolute inset-0 opacity-[0.35]"
            style={{
              backgroundImage:
                'linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)',
              backgroundSize: '48px 48px',
            }}
            aria-hidden="true"
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-8 text-center">
            <span className="flex h-14 w-14 items-center justify-center border border-[#e10600]" aria-hidden="true">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#e10600" strokeWidth="2">
                <path d="M12 21s-7-5.5-7-11a7 7 0 1 1 14 0c0 5.5-7 11-7 11z" />
                <circle cx="12" cy="10" r="2.5" />
              </svg>
            </span>
            <p className="font-display text-xs font-bold uppercase tracking-[0.3em] text-white/60">
              Map placeholder
            </p>
            <p className="max-w-xs text-sm leading-relaxed text-white/40">
              Replace this block with the gym's Google Maps embed.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
