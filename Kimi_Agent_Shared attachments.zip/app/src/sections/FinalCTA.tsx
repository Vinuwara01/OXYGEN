import cta from '@/assets/cta.jpg'

export default function FinalCTA() {
  return (
    <section className="relative overflow-hidden bg-[#0a0a0a] text-white">
      <div className="absolute inset-0">
        <img
          src={cta}
          alt=""
          aria-hidden="true"
          loading="lazy"
          className="h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-[#0a0a0a]/60" />
      </div>

      <div className="relative mx-auto flex max-w-[1400px] flex-col items-center px-5 py-32 text-center md:px-10 md:py-52">
        <h2 className="reveal font-display text-[16vw] font-black uppercase leading-[0.9] tracking-[-0.02em] md:text-[9vw]">
          Ready to<br />
          <span className="text-[#e10600]">train?</span>
        </h2>
        <a
          href="#memberships"
          className="reveal btn-wipe btn-wipe-red mt-12 inline-block bg-[#e10600] px-14 py-5 font-display text-sm font-bold uppercase tracking-[0.3em] text-white"
          data-delay="150"
        >
          Join Oxygen
        </a>
      </div>
    </section>
  )
}
