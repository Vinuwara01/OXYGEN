export default function Results() {
  return (
    <section className="bg-white text-[#0a0a0a]">
      <div className="mx-auto max-w-[1400px] px-5 py-28 text-center md:px-10 md:py-44">
        <h2 className="reveal font-display text-[11vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5.6vw]">
          Your next level<br />starts here.
        </h2>
        <p className="reveal mx-auto mt-7 max-w-md text-lg leading-relaxed text-[#0a0a0a]/60" data-delay="120">
          Show up. Put in the work. Build something stronger.
        </p>
        <a
          href="#memberships"
          className="reveal btn-wipe btn-wipe-red mt-10 inline-block bg-[#e10600] px-12 py-4 font-display text-xs font-bold uppercase tracking-[0.25em] text-white"
          data-delay="220"
        >
          Start Training
        </a>
      </div>
    </section>
  )
}
