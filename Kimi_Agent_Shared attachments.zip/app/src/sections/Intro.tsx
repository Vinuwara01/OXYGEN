import intro from '@/assets/intro.jpg'

export default function Intro() {
  return (
    <section id="intro" className="relative bg-white text-[#0a0a0a]">
      <div className="mx-auto grid max-w-[1400px] grid-cols-1 gap-12 px-5 py-24 md:px-10 md:py-36 lg:grid-cols-12 lg:gap-8">
        {/* Vertical edge label */}
        <div className="hidden lg:col-span-1 lg:flex lg:items-start lg:justify-center">
          <span className="edge-label reveal font-display text-[10px] font-bold uppercase text-[#0a0a0a]/40">
            Oxygen Gym
          </span>
        </div>

        {/* Text */}
        <div className="lg:col-span-6 lg:pt-10">
          <p className="eyebrow reveal mb-6">More than a gym</p>
          <h2
            className="reveal font-display text-[13vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5.4vw]"
            data-delay="80"
          >
            More than<br />a gym.
          </h2>
          <p
            className="reveal mt-8 max-w-md text-lg leading-relaxed text-[#0a0a0a]/65"
            data-delay="160"
          >
            Oxygen Gym is built for people who want more from their training.
            Quality equipment, focused coaching and an environment designed to
            help you perform.
          </p>
          <a
            href="#training"
            className="reveal group mt-10 inline-flex items-center gap-3 font-display text-xs font-bold uppercase tracking-[0.25em] text-[#0a0a0a]"
            data-delay="240"
          >
            <span className="border-b-2 border-[#e10600] pb-1">How we train</span>
            <span className="transition-transform duration-300 group-hover:translate-x-1.5">→</span>
          </a>
        </div>

        {/* Image — offset, breaks the grid downward */}
        <div className="lg:col-span-5 lg:-mt-4">
          <div className="reveal-img relative aspect-[4/5] overflow-hidden lg:translate-y-16">
            <img
              src={intro}
              alt="The Oxygen Gym training floor in low cinematic light"
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
