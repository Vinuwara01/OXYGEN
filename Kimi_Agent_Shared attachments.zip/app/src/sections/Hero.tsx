import { useEffect, useState } from 'react'
import hero from '@/assets/hero.jpg'

export default function Hero() {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    const t = window.setTimeout(() => setLoaded(true), 80)
    return () => window.clearTimeout(t)
  }, [])

  return (
    <section id="home" className="relative flex min-h-svh items-end overflow-hidden bg-[#0a0a0a]">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={hero}
          alt="Oxygen Gym training floor with free weights in dramatic low light"
          className={`h-full w-full object-cover transition-[transform,opacity] duration-[2000ms] ease-out ${
            loaded ? 'scale-100 opacity-100' : 'scale-105 opacity-0'
          }`}
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/35 to-[#0a0a0a]/55" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto w-full max-w-[1400px] px-5 pb-20 pt-40 md:px-10 md:pb-28">
        <p
          className={`eyebrow mb-6 transition-all duration-700 ${
            loaded ? 'translate-y-0 opacity-100' : 'translate-y-5 opacity-0'
          }`}
        >
          Oxygen Gym — Sri Lanka
        </p>

        <h1 className="font-display font-black uppercase leading-[0.92] tracking-[-0.02em] text-white">
          <span
            className={`block text-[15vw] transition-all delay-100 duration-1000 md:text-[9.5vw] lg:text-[8.5vw] ${
              loaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
          >
            Train With
          </span>
          <span
            className={`block text-[15vw] text-[#e10600] transition-all delay-200 duration-1000 md:text-[9.5vw] lg:text-[8.5vw] ${
              loaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
          >
            Purpose.
          </span>
        </h1>

        <div
          className={`mt-8 flex flex-col gap-8 transition-all delay-300 duration-1000 md:mt-10 md:flex-row md:items-end md:justify-between ${
            loaded ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
          }`}
        >
          <p className="max-w-md text-base leading-relaxed text-white/70 md:text-lg">
            Premium training. Serious results.
          </p>

          <div className="flex flex-col gap-3 sm:flex-row">
            <a
              href="#memberships"
              className="btn-wipe btn-wipe-red bg-[#e10600] px-9 py-4 text-center font-display text-xs font-bold uppercase tracking-[0.25em] text-white"
            >
              Join Now
            </a>
            <a
              href="#intro"
              className="btn-wipe btn-wipe-ghost border border-white/40 px-9 py-4 text-center font-display text-xs font-bold uppercase tracking-[0.25em] text-white"
            >
              Explore the Gym
            </a>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div
        className={`absolute bottom-6 right-6 hidden items-center gap-3 transition-opacity delay-700 duration-1000 md:flex ${
          loaded ? 'opacity-100' : 'opacity-0'
        }`}
        aria-hidden="true"
      >
        <span className="font-display text-[10px] font-bold uppercase tracking-[0.35em] text-white/50">
          Scroll
        </span>
        <span className="h-px w-12 bg-white/40" />
      </div>
    </section>
  )
}
