const PRINCIPLES = [
  {
    n: '01',
    title: 'Performance',
    text: 'Everything here exists to make you better — nothing is decoration.',
  },
  {
    n: '02',
    title: 'Precision',
    text: 'Deliberate programming, proper form, measured effort.',
  },
  {
    n: '03',
    title: 'Progress',
    text: 'Small gains, tracked honestly, compounded over time.',
  },
  {
    n: '04',
    title: 'Consistency',
    text: 'The work repeats. That is where results come from.',
  },
]

export default function Principles() {
  return (
    <section className="bg-[#0a0a0a] text-white">
      <div className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-36">
        <div className="mb-16 flex items-end justify-between gap-6 md:mb-20">
          <div>
            <p className="eyebrow reveal mb-5">Why Oxygen</p>
            <h2
              className="reveal font-display text-4xl font-black uppercase leading-[0.95] tracking-[-0.02em] md:text-6xl"
              data-delay="80"
            >
              Built on four<br />principles.
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 border-t border-white/10 sm:grid-cols-2 lg:grid-cols-4">
          {PRINCIPLES.map((p, i) => (
            <div
              key={p.n}
              className="reveal group border-b border-white/10 py-10 pr-6 sm:border-r sm:px-8 sm:py-12 sm:first:pl-0 sm:last:border-r-0 lg:py-14"
              data-delay={i * 90}
            >
              <span className="font-display text-6xl font-black leading-none text-white/15 transition-colors duration-500 group-hover:text-[#e10600] md:text-7xl">
                {p.n}
              </span>
              <h3 className="mt-8 font-display text-xl font-extrabold uppercase tracking-[0.08em] md:text-2xl">
                {p.title}
              </h3>
              <p className="mt-4 max-w-[26ch] text-sm leading-relaxed text-white/55">
                {p.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
