const TIERS = [
  {
    name: 'Basic',
    features: ['Access to the gym', 'Standard equipment', 'Flexible training'],
    featured: false,
  },
  {
    name: 'Pro',
    features: ['Full gym access', 'Training guidance', 'Progress tracking'],
    featured: true,
  },
  {
    name: 'Elite',
    features: ['Full gym access', 'Personal training', 'Priority support'],
    featured: false,
  },
]

export default function Memberships() {
  return (
    <section id="memberships" className="bg-white text-[#0a0a0a]">
      <div className="mx-auto max-w-[1400px] px-5 py-24 md:px-10 md:py-36">
        <p className="eyebrow reveal mb-5">Memberships</p>
        <div className="mb-14 flex flex-col gap-6 md:mb-20 md:flex-row md:items-end md:justify-between">
          <h2
            className="reveal font-display text-[12vw] font-black uppercase leading-[0.94] tracking-[-0.02em] md:text-7xl lg:text-[5.4vw]"
            data-delay="80"
          >
            Choose your<br />commitment.
          </h2>
          <p className="reveal max-w-sm text-base leading-relaxed text-[#0a0a0a]/60" data-delay="160">
            Three tiers, no lock-in complexity. Talk to the team and we will
            match the plan to your goals.
          </p>
        </div>

        <div className="grid grid-cols-1 items-stretch gap-5 lg:grid-cols-3">
          {TIERS.map((t, i) => (
            <div
              key={t.name}
              className={`reveal relative flex flex-col border p-8 transition-transform duration-500 md:p-10 ${
                t.featured
                  ? 'border-[#0a0a0a] bg-[#0a0a0a] text-white lg:-translate-y-4'
                  : 'border-[#0a0a0a]/15 bg-white hover:border-[#0a0a0a]/40'
              }`}
              data-delay={i * 100}
            >
              {t.featured && (
                <span className="absolute right-6 top-6 bg-[#e10600] px-3 py-1.5 font-display text-[10px] font-bold uppercase tracking-[0.25em] text-white">
                  Recommended
                </span>
              )}

              <span
                className={`font-display text-[11px] font-bold uppercase tracking-[0.3em] ${
                  t.featured ? 'text-white/50' : 'text-[#0a0a0a]/45'
                }`}
              >
                Plan 0{i + 1}
              </span>
              <h3 className="mt-4 font-display text-4xl font-black uppercase tracking-tight md:text-5xl">
                {t.name}
              </h3>

              <p
                className={`mt-6 border-y py-5 font-display text-sm font-bold uppercase tracking-[0.2em] ${
                  t.featured ? 'border-white/15 text-[#e10600]' : 'border-[#0a0a0a]/10 text-[#e10600]'
                }`}
              >
                Contact for price
              </p>

              <ul className="mt-7 flex flex-col gap-4">
                {t.features.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-sm md:text-base">
                    <span className="h-[6px] w-[6px] shrink-0 bg-[#e10600]" aria-hidden="true" />
                    <span className={t.featured ? 'text-white/80' : 'text-[#0a0a0a]/70'}>{f}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                className={`btn-wipe mt-10 block py-4 text-center font-display text-xs font-bold uppercase tracking-[0.25em] ${
                  t.featured
                    ? 'btn-wipe-red bg-[#e10600] text-white'
                    : 'btn-wipe-dark border border-[#0a0a0a] text-[#0a0a0a]'
                }`}
              >
                Get Started
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
