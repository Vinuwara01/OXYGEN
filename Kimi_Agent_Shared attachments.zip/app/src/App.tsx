import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import Hero from '@/sections/Hero'
import Intro from '@/sections/Intro'
import Principles from '@/sections/Principles'
import Training from '@/sections/Training'
import Memberships from '@/sections/Memberships'
import Experience from '@/sections/Experience'
import Results from '@/sections/Results'
import About from '@/sections/About'
import Contact from '@/sections/Contact'
import FinalCTA from '@/sections/FinalCTA'
import { useReveal } from '@/hooks/useReveal'

export default function App() {
  useReveal()

  return (
    <div className="bg-[#0a0a0a]">
      <Nav />
      <main>
        <Hero />
        <Intro />
        <Principles />
        <Training />
        <Memberships />
        <Experience />
        <Results />
        <About />
        <Contact />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  )
}
